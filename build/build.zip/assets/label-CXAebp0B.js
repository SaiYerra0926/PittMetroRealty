import{c as i,P as c,h as n}from"./index-C5SlZrPk.js";import{r as t,j as s,b as d}from"./ui-DVJ6EJIP.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=i("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]]);var m="Label",o=t.forwardRef((a,r)=>s.jsx(c.label,{...a,ref:r,onMouseDown:e=>{e.target.closest("button, input, select, textarea")||(a.onMouseDown?.(e),!e.defaultPrevented&&e.detail>1&&e.preventDefault())}}));o.displayName=m;var l=o;const f=d("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"),p=t.forwardRef(({className:a,...r},e)=>s.jsx(l,{ref:e,className:n(f(),a),...r}));p.displayName=l.displayName;export{p as L,y as U};
